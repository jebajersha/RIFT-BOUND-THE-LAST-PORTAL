# RIFTBOUND: THE LAST PORTAL

Cooperative real-time multiplayer fantasy puzzle game for 2–6 players.

## Features
- Create rooms and invite friends with a six-character code
- Join from another browser/device
- Five timed fantasy riddles, hints, team score and individual points
- Host controls for starting and advancing rounds
- Responsive phone and desktop interface

## Run on Mac
1. Install Node.js 18 or newer.
2. Extract this ZIP and open the folder in VS Code.
3. Open Terminal in the project folder.
4. Run `npm install`
5. Run `npm start`
6. Open `http://localhost:3000`

## Deploy
For Render, create a Node Web Service from this project/repository.
Build command: `npm install`
Start command: `npm start`
The server uses `process.env.PORT` and Socket.IO.

Note: Active rooms are stored in memory and reset if the server restarts. For a production-ready game, add persistence, reconnect support, moderation, and more levels.
