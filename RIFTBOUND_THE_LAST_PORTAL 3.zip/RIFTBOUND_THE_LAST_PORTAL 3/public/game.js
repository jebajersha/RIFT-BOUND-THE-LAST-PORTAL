const socket=io(),$=id=>document.getElementById(id);let room=null,host=false;
$("createTab").onclick=()=>{ $("createArea").classList.remove("hide");$("joinArea").classList.add("hide");$("createTab").classList.add("active");$("joinTab").classList.remove("active");};
$("joinTab").onclick=()=>{ $("joinArea").classList.remove("hide");$("createArea").classList.add("hide");$("joinTab").classList.add("active");$("createTab").classList.remove("active");};
$("create").onclick=()=>socket.emit("room:create",{name:$("name").value});
$("join").onclick=()=>socket.emit("room:join",{name:$("name").value,code:$("roomCode").value.trim()});
$("start").onclick=()=>socket.emit("game:start",{code:room.code});
$("submit").onclick=()=>{socket.emit("game:answer",{code:room.code,answer:$("answer").value});$("answer").value="";};
$("answer").onkeydown=e=>{if(e.key==="Enter")$("submit").click();};
$("hint").onclick=()=>socket.emit("game:hint",{code:room.code});
$("next").onclick=()=>socket.emit("game:next",{code:room.code});
$("copy").onclick=async()=>{try{await navigator.clipboard.writeText(room.code);$("copy").textContent="Copied!";}catch{$("copy").textContent=room.code;}};
socket.on("room:joined",r=>{room=r;host=r.host===socket.id;$("home").classList.add("hide");$("game").classList.remove("hide");render(r);});
socket.on("room:update",render);socket.on("game:error",m=>$("error").textContent=m);socket.on("game:feedback",m=>$("feedback").textContent=m);socket.on("game:notice",m=>$("notice").textContent=m);
function render(r){if(!room||r.code!==room.code)return;room=r;host=r.host===socket.id;$("code").textContent=r.code;$("round").textContent=r.round?`${r.round}/5`:"Lobby";$("score").textContent=r.score;$("time").textContent=r.status==="playing"?r.timeLeft+"s":"—";$("players").innerHTML=r.players.map(p=>`<div class="player"><b>✦ ${safe(p.name)}</b><span>${safe(p.power)} · ${p.score} pts</span></div>`).join("");$("start").classList.toggle("hide",!host||r.status!=="lobby");$("lobby").classList.toggle("hide",r.status!=="lobby");$("puzzle").classList.toggle("hide",r.status!=="playing");$("nextArea").classList.toggle("hide",r.status!=="round-over");$("done").classList.toggle("hide",r.status!=="finished");if(r.puzzle){$("title").textContent=r.puzzle.title;$("clue").textContent=r.puzzle.clue;$("hintText").textContent=r.puzzle.hint?"Hint: "+r.puzzle.hint:"";}$("hint").disabled=!!r.puzzle?.hint;$("next").classList.toggle("hide",!host);if(r.status==="finished")$("winner").textContent=`Top explorer: ${r.winner}. Team score: ${r.score}.`;}
function safe(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}