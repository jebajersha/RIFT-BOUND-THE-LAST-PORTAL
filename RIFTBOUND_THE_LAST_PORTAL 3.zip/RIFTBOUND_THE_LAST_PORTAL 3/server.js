
const express=require("express"),http=require("http"),{Server}=require("socket.io"),crypto=require("crypto");
const app=express(),server=http.createServer(app),io=new Server(server),PORT=process.env.PORT||3000;
app.use(express.static("public")); app.get("/health",(_,r)=>r.json({ok:true}));
const rooms=new Map(),powers=["Clue Keeper","Time Weaver","Rune Reader","Portal Guardian","Star Scout","Crystal Mage"];
const puzzles=[
{title:"The Moon Gate",clue:"I shine at night, change my shape, and guide the tides. What am I?",answer:"moon",hint:"Look up after sunset."},
{title:"The Ember Lock",clue:"I am born in a spark, dance without feet, and can warm or destroy. What am I?",answer:"fire",hint:"A campfire is made of me."},
{title:"The Sky Bridge",clue:"I have keys but open no doors. I have space but no room. What am I?",answer:"keyboard",hint:"You use me to type."},
{title:"The Crystal Well",clue:"The more you take from me, the bigger I become. What am I?",answer:"hole",hint:"Digging makes me larger."},
{title:"The Time Vault",clue:"I have hands but cannot clap, and a face but cannot smile. What am I?",answer:"clock",hint:"I help you know the time."}
];
const code=()=>crypto.randomBytes(3).toString("hex").toUpperCase();
function view(r){return {code:r.code,host:r.host,status:r.status,round:r.round,score:r.score,timeLeft:r.timeLeft,puzzle:r.puzzle?{title:r.puzzle.title,clue:r.puzzle.clue,hint:r.hintUsed?r.puzzle.hint:null}:null,winner:r.winner||null,players:[...r.players.values()].map(p=>({id:p.id,name:p.name,power:p.power,score:p.score}))};}
function update(r){io.to(r.code).emit("room:update",view(r));}
function start(r){r.status="playing";r.round++;r.timeLeft=75;r.hintUsed=false;r.puzzle=puzzles[(r.round-1)%puzzles.length];clearInterval(r.timer);r.timer=setInterval(()=>{r.timeLeft--;if(r.timeLeft<=0){clearInterval(r.timer);r.timer=null;r.status="round-over";io.to(r.code).emit("game:notice","Time is up! The portal remains sealed.");}update(r);},1000);update(r);}
io.on("connection",s=>{
s.on("room:create",({name})=>{let c=code(),r={code:c,host:s.id,players:new Map(),status:"lobby",round:0,score:0,timeLeft:75,puzzle:null,hintUsed:false};r.players.set(s.id,{id:s.id,name:String(name||"Explorer").slice(0,18),power:powers[0],score:0});rooms.set(c,r);s.join(c);s.emit("room:joined",view(r));update(r);});
s.on("room:join",({code:c,name})=>{let r=rooms.get(String(c||"").toUpperCase());if(!r)return s.emit("game:error","Room code not found.");if(r.players.size>=6)return s.emit("game:error","Room is full (maximum 6 players).");if(r.status!=="lobby")return s.emit("game:error","This adventure has already started.");r.players.set(s.id,{id:s.id,name:String(name||"Explorer").slice(0,18),power:powers[r.players.size%6],score:0});s.join(r.code);s.emit("room:joined",view(r));update(r);});
s.on("game:start",({code:c})=>{let r=rooms.get(c);if(!r||r.host!==s.id)return;if(r.players.size<2)return s.emit("game:error","Invite at least one friend first.");start(r);});
s.on("game:hint",({code:c})=>{let r=rooms.get(c);if(!r||r.status!=="playing"||r.hintUsed)return;r.hintUsed=true;r.score=Math.max(0,r.score-2);update(r);});
s.on("game:answer",({code:c,answer})=>{let r=rooms.get(c);if(!r||r.status!=="playing")return;if(String(answer||"").trim().toLowerCase()===r.puzzle.answer){let p=r.players.get(s.id);if(p)p.score+=10;r.score+=10;r.status="round-over";clearInterval(r.timer);r.timer=null;io.to(c).emit("game:notice",(p?.name||"An explorer")+" solved the rune! +10 points. Portal opening!");update(r);}else s.emit("game:feedback","Not quite! Try another answer.");});
s.on("game:next",({code:c})=>{let r=rooms.get(c);if(!r||r.host!==s.id||r.status!=="round-over")return;if(r.round>=5){r.status="finished";r.winner=[...r.players.values()].sort((a,b)=>b.score-a.score)[0]?.name||"The team";io.to(c).emit("game:notice","The portal has been restored!");update(r);}else start(r);});
s.on("disconnect",()=>{for(const [c,r] of rooms){if(r.players.delete(s.id)){if(r.host===s.id)r.host=r.players.keys().next().value||null;if(!r.players.size){clearInterval(r.timer);rooms.delete(c);}else update(r);}}});
});
server.listen(PORT,()=>console.log("RIFTBOUND: THE LAST PORTAL running on port "+PORT));
